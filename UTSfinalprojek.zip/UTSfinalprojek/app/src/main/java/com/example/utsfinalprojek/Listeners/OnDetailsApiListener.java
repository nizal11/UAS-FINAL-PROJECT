package com.example.utsfinalprojek.Listeners;

import com.example.utsfinalprojek.Models.DetailApiResponse;

public interface OnDetailsApiListener {
    void onResponse(DetailApiResponse response);
    void onError(String message);
}
