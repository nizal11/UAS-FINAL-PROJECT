package com.example.utsfinalprojek.Listeners;

import com.example.utsfinalprojek.Models.SearchApiResponse;

public interface OnSearchApiListener {
    void onResponse(SearchApiResponse response);
    void onError(String message);
}
