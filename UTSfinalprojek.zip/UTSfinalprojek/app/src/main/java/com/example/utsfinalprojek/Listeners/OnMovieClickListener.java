package com.example.utsfinalprojek.Listeners;

public interface OnMovieClickListener {
    void onMovieClicked(String id);
}
